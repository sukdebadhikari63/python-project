# Student Performance Analytics System

## 1. Project Title
**Student Performance Analytics System**
Student Name: _<your name>_ | Course: Python with AI (EWB Courses)

## 2. Objective
Teachers often need to turn raw marks into useful information: who is doing well, who needs help, and which subjects are weak. This project reads student records from a CSV file and uses Python, NumPy and Pandas to automatically calculate totals, averages, grades, pass/fail status, subject-wise performance and top performers.

## 3. Technologies Used
- Python 3
- NumPy – numerical calculations (sum, mean, median, max, min, standard deviation)
- Pandas – loading, organising, filtering and grouping data

## 4. Dataset Description
`students.csv` contains **20 student records** with 9 columns:

| Column | Description |
|---|---|
| Student_ID | Unique ID (S101–S120) |
| Name | Student name |
| Department | Computer Science, Electronics, Electrical, Mechanical, Civil |
| Maths, Physics, Chemistry, English, Computer_Science | Marks out of 100 |
| Attendance | Attendance percentage |

## 5. Implementation
1. **Load data** – `load_data()` reads the CSV into a Pandas DataFrame; the program prints record count, columns and missing values.
2. **Total & average** – `calculate_total()` uses `np.sum` across subject columns; `calculate_average()` divides and rounds with NumPy.
3. **Grades** – `assign_grade()` loops through a grading table:

   | Average | Grade |
   |---|---|
   | 90+ | A+ |
   | 80–89 | A |
   | 70–79 | B |
   | 60–69 | C |
   | 50–59 | D |
   | 40–49 | E |
   | below 40 | F |

4. **Pass/Fail rule** – a student passes only if marks are **≥ 40 in every subject** and attendance is **≥ 75%**. `process_students()` loops over each row to apply this.
5. **Ranking** – students are ranked by total marks.
6. **Analysis** – class statistics, subject-wise analysis, top performers, grade distribution, department-wise results and the list of failed students.
7. **Output** – results are printed in a readable report and saved to `results.csv`.

## 6. Key Features
- `load_data()` – read CSV into DataFrame
- `calculate_total()` / `calculate_average()` – NumPy-based calculations
- `assign_grade()` – grading rule
- `check_pass_fail()` – pass/fail condition
- `process_students()` – adds Total, Average, Grade, Result, Rank
- `class_statistics()` – class average, highest, lowest, median, std. deviation, pass %
- `subject_analysis()` – highest / lowest / average / pass % per subject
- `top_performers()` – top N students
- `department_analysis()` and `grade_distribution()`

## 7. Output / Screenshots
Run `python main.py` and add screenshots of the output here, e.g.:

`![Output](screenshots/output1.png)`

Sample results from the included dataset:
- Class average: **69.42**
- Passed: **15 / 20 (75%)**
- Highest average: **Ishita Banerjee (93.0, grade A+)**
- Best subject: **Computer_Science (72.5)**; weakest: **Chemistry (66.2)**

## 8. Final Outcome
The system successfully processes the full dataset and produces a clear report covering every required feature: totals, averages, grades, pass/fail statistics, highest/lowest/average performance, subject-wise analysis and top performers – without needing to read the code.

## 9. Challenges & Learning
_(Write in your own words – for example: handling the pass/fail rule with multiple conditions, choosing between loops and vectorised NumPy operations, using `groupby` for department analysis, and learning to organise code into reusable functions.)_

## 10. GitHub Repository
_Add your repository link here:_ `https://github.com/<your-username>/student-performance-analytics`

---

## How to Run
```bash
pip install -r requirements.txt
python main.py
```

## Project Structure
```
student-performance-analytics/
├── main.py            # runs the analysis and prints the report
├── functions.py       # reusable calculation functions
├── students.csv       # dataset (20 records)
├── requirements.txt
└── README.md          # project documentation
```
