"""
main.py
Student Performance Analytics System
Runs the full analysis and prints the final report.
"""

import pandas as pd
import functions as fn

DATA_FILE = "students.csv"
pd.set_option("display.width", 200)
pd.set_option("display.max_columns", None)


def print_header(title):
    print("\n" + "=" * 70)
    print(title.center(70))
    print("=" * 70)


def main():
    # ---------- Step 2: Read the data ----------
    print_header("STEP 1: DATASET OVERVIEW")
    df = fn.load_data(DATA_FILE)
    print(f"Number of records : {df.shape[0]}")
    print(f"Number of columns : {df.shape[1]}")
    print(f"Columns           : {list(df.columns)}")
    print(f"Missing values    : {int(df.isnull().sum().sum())}")
    print("\nFirst 5 records:")
    print(df.head().to_string(index=False))

    # ---------- Step 3: Process the data ----------
    print_header("STEP 2: STUDENT RESULTS (Total, Average, Grade, Result)")
    processed = fn.process_students(df)
    print(processed[["Student_ID", "Name", "Total", "Average",
                     "Grade", "Result", "Rank"]].to_string(index=False))

    # ---------- Step 4: Analysis ----------
    stats = fn.class_statistics(processed)
    print_header("STEP 3: OVERALL CLASS STATISTICS")
    print(f"Total students     : {stats['total_students']}")
    print(f"Class average      : {stats['class_average']}")
    print(f"Highest average    : {stats['highest_average']}")
    print(f"Lowest average     : {stats['lowest_average']}")
    print(f"Median average     : {stats['median_average']}")
    print(f"Standard deviation : {stats['std_dev']}")
    print(f"Average attendance : {stats['average_attendance']}%")
    print(f"Students passed    : {stats['passed']}")
    print(f"Students failed    : {stats['failed']}")
    print(f"Pass percentage    : {stats['pass_percentage']}%")

    print_header("STEP 4: SUBJECT-WISE PERFORMANCE")
    subject_df = fn.subject_analysis(processed)
    print(subject_df.to_string(index=False))
    best = subject_df.loc[subject_df["Average"].idxmax()]
    weakest = subject_df.loc[subject_df["Average"].idxmin()]
    print(f"\nBest subject (highest average)   : {best['Subject']} ({best['Average']})")
    print(f"Weakest subject (lowest average) : {weakest['Subject']} ({weakest['Average']})")

    print_header("STEP 5: TOP 5 PERFORMERS")
    print(fn.top_performers(processed, n=5).to_string(index=False))

    topper = processed.loc[processed["Average"].idxmax()]
    lowest = processed.loc[processed["Average"].idxmin()]
    print(f"\nHighest average : {topper['Name']} ({topper['Average']})")
    print(f"Lowest average  : {lowest['Name']} ({lowest['Average']})")

    print_header("GRADE DISTRIBUTION")
    print(fn.grade_distribution(processed).to_string())

    print_header("DEPARTMENT-WISE PERFORMANCE")
    print(fn.department_analysis(processed).to_string(index=False))

    print_header("STUDENTS WHO FAILED")
    failed = processed[processed["Result"] == "Fail"]
    print(failed[["Student_ID", "Name", "Average", "Attendance"]].to_string(index=False))

    # Save the processed data
    processed.to_csv("results.csv", index=False)
    print("\nFull results saved to results.csv")


if __name__ == "__main__":
    main()
