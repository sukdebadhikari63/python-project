"""
functions.py
Reusable calculation and processing functions for the
Student Performance Analytics System.
"""

import numpy as np
import pandas as pd

# ---------- Configuration (grading & pass/fail rules) ----------
SUBJECTS = ["Maths", "Physics", "Chemistry", "English", "Computer_Science"]
PASS_MARK = 40          # minimum marks needed in EVERY subject
MIN_ATTENDANCE = 75     # minimum attendance % needed to pass
MAX_MARKS_PER_SUBJECT = 100

# Grading rule based on average marks
GRADE_RULES = [
    (90, "A+"),
    (80, "A"),
    (70, "B"),
    (60, "C"),
    (50, "D"),
    (40, "E"),
]


# ---------- Data loading ----------
def load_data(file_path):
    """Read the student CSV file into a Pandas DataFrame."""
    return pd.read_csv(file_path)


# ---------- Per-student calculations ----------
def calculate_total(df, subjects=SUBJECTS):
    """Return a NumPy array with total marks for every student."""
    marks = df[subjects].to_numpy()
    return np.sum(marks, axis=1)


def calculate_average(total_marks, num_subjects=len(SUBJECTS)):
    """Return average marks (rounded to 2 decimals) from total marks."""
    return np.round(total_marks / num_subjects, 2)


def assign_grade(average):
    """Return a grade letter for a given average using GRADE_RULES."""
    for minimum, grade in GRADE_RULES:
        if average >= minimum:
            return grade
    return "F"


def check_pass_fail(row, subjects=SUBJECTS):
    """
    A student PASSES only if:
      1. marks in every subject >= PASS_MARK, and
      2. attendance >= MIN_ATTENDANCE
    Otherwise the student FAILS.
    """
    all_subjects_cleared = all(row[subject] >= PASS_MARK for subject in subjects)
    attendance_ok = row["Attendance"] >= MIN_ATTENDANCE
    return "Pass" if (all_subjects_cleared and attendance_ok) else "Fail"


def process_students(df):
    """Add Total, Average, Grade, Result and Rank columns to the DataFrame."""
    result = df.copy()

    result["Total"] = calculate_total(result)
    result["Average"] = calculate_average(result["Total"].to_numpy())

    # Loops used here: iterate row by row for grade and pass/fail status
    grades, results = [], []
    for _, row in result.iterrows():
        grades.append(assign_grade(row["Average"]))
        results.append(check_pass_fail(row))
    result["Grade"] = grades
    result["Result"] = results

    result["Rank"] = result["Total"].rank(method="min", ascending=False).astype(int)
    return result


# ---------- Class-level analysis ----------
def class_statistics(df):
    """Return a dictionary of overall class statistics."""
    averages = df["Average"].to_numpy()
    return {
        "total_students": len(df),
        "class_average": round(float(np.mean(averages)), 2),
        "highest_average": float(np.max(averages)),
        "lowest_average": float(np.min(averages)),
        "median_average": round(float(np.median(averages)), 2),
        "std_dev": round(float(np.std(averages)), 2),
        "passed": int((df["Result"] == "Pass").sum()),
        "failed": int((df["Result"] == "Fail").sum()),
        "pass_percentage": round((df["Result"] == "Pass").mean() * 100, 2),
        "average_attendance": round(float(df["Attendance"].mean()), 2),
    }


def subject_analysis(df, subjects=SUBJECTS):
    """Return a DataFrame with highest, lowest, average and pass % per subject."""
    rows = []
    for subject in subjects:
        scores = df[subject].to_numpy()
        rows.append({
            "Subject": subject,
            "Highest": int(np.max(scores)),
            "Lowest": int(np.min(scores)),
            "Average": round(float(np.mean(scores)), 2),
            "Pass_%": round(float(np.mean(scores >= PASS_MARK) * 100), 2),
        })
    return pd.DataFrame(rows)


def top_performers(df, n=5):
    """Return the top n students ranked by total marks."""
    return df.sort_values("Total", ascending=False).head(n)[
        ["Rank", "Student_ID", "Name", "Department", "Total", "Average", "Grade"]
    ]


def department_analysis(df):
    """Average marks and pass count grouped by department."""
    return df.groupby("Department").agg(
        Students=("Student_ID", "count"),
        Avg_Marks=("Average", "mean"),
        Avg_Attendance=("Attendance", "mean"),
        Passed=("Result", lambda r: (r == "Pass").sum()),
    ).round(2).reset_index()


def grade_distribution(df):
    """Count of students in each grade."""
    order = [g for _, g in GRADE_RULES] + ["F"]
    counts = df["Grade"].value_counts()
    return counts.reindex(order, fill_value=0)
